/* *****************************************************************************
 *  Name:              Miklós Szilas
 *  Coursera User ID:  szilas.miklos@gmail.com
 *  Last modified:     05/04/2020
 *  Program:           HelloWorld.java
 *  Description:       Says 'Hello World!' as obvious.
 **************************************************************************** */

public class HelloWorld {

    public static void main(String[] args) {

        System.out.println("Hello World!");

    }
}
