/* *****************************************************************************
 *  Name:              Miklós Szilas
 *  Coursera User ID:  szilas.miklos@gmail.com
 *  Last modified:     05/04/2020
 *  Program:           RightTriangle.java
 *  Description:       Decides whether a triangle is a right triangle or not,
 *                     according to the system line argument data that represent
 *                     the triangle's sides lengths.
 **************************************************************************** */

public class RightTriangle {

    public static void main(String[] args) {

        // Declaring a boolean for result. Decalring integers for input data.

        boolean result;

        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        int c = Integer.parseInt(args[2]);

        // Pythagorean theorem, checking floats, printing out the result

        System.out.println(Math.abs(c * c - (a * a + b * b)) < 0.0001);
    }
}
